from pymongo import MongoClient

client=MongoClient("mongodb://localhost:27017/")

db=client["hotel_booking"]
hotel=db["hotel"]

db.hotel.delete_many({})

hotel=[
    {
        "name":"taj",
        "location":"mumbai",
        "price":3000,
        "image":"static/img/1.jpg"
    },

 {
        "name":"super",
        "location":"coimbatore",
        "price":4000,
        "image":"static/img/2.jpg"
    },

 {
        "name":"Ashok",
        "location":"bengaluru",
        "price":5000,
        "image":"static/img/3.jpg"
    }
]

db.hotel.insert_many(hotel)

print("done")

