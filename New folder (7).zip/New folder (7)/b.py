from flask import Flask,render_template,request,redirect,url_for
from pymongo import MongoClient
import gridfs

client=MongoClient("mongodb://localhost:27017/")
db=client["hotel_booking"]
users=db['user']
hotels=db['hotel']
fs=gridfs.GridFS(db)

app = Flask(__name__)

@app.route('/',methods=["GET","POST"])
def login():
    if request.method=='POST':
        username=request.form["username"]
        password=request.form["password"]

        user=users.find_one({"username":username,"password":password})

        if user:
            return redirect(url_for('dash'))

        return render_template('login.html',error="username or password inavalid")

    return render_template("login.html")

@app.route('/register',methods=["GET","POST"])
def register():
    if request.method=='POST':
        username=request.form["username"]
        password=request.form["password"]

        if users.find_one({"username":username}):
            return render_template("register.html",error="username toke")
        users.insert_one({"username":username,"password":password})
        return redirect(url_for('login'))

    return render_template("register.html")

@app.route("/dash")
def dash():
    hotels_list=list(hotels.find())
    for hote in hotels_list:
        hote['_id']=str(hote['_id'])
    return render_template("dash.html",hotellss=hotels_list)


if __name__=="__main__":
    app.run()
