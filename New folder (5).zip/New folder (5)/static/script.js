function getmovie() {
    fetch(`/recommend`)
    .then(response => response.json())
    .then(data => {
        document.getElementById("movieTitle").innerText = data.title;
        document.getElementById("movieImage").src = `/static/${data.image}`;
    });
}


function bookMovie(title) {
    alert(`Successfully booked seat(s) for ${title}!`);
}

function details(title) {
    alert(`Details of ${title}:\nGenre: Example Genre\nRating`);
}

function fav(title) {
    alert(`${title} added to your favorites!`);
}

function trailer(title) {
    alert(`Opening trailer for ${title}...`);
}
